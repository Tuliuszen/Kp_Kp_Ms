if(window.location.pathname=="/kontakt"){
	$( "div.formularz_kontaktowy h2" ).ready( function(){
		$("h1").wrapInner("<span></span>");
		$("h2").wrapInner("<span></span>");
	});
}else{
	$( document ).ready( function(){
		$("h1").wrapInner("<span></span>");
		$("h2").wrapInner("<span></span>");
	});
};