<html>
	<head>
		<meta charset="UTF-8" />
	</head>
	<body>
		<?php
			$x=12;
			
			if($x < 20){
				print('<script language="JavaScript">alert("Zmienna x jest mniejsza niż 20")</script>');
			}else if($x > 20){
				print('<script language="JavaScript">alert("Zmienna x jest większa niż 20")</script>');
			};
		?>
	</body>
</html>